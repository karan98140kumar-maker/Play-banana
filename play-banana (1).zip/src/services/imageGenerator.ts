import { GoogleGenAI } from "@google/genai";

export async function generateAppIcon() {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-image-preview',
      contents: {
        parts: [
          {
            text: "A professional app icon: A circular emblem with a white border on a vibrant yellow and green gradient background. Inside the circle, a peeled banana is centered, surrounded by stacks of shiny gold coins with dollar symbols and several green dollar bills. The word 'Play' is written in clean white sans-serif font at the top inside the circle. The word 'Banana' is written in large, bold, rounded yellow letters with a thick dark green outline at the bottom, partially overlapping the circle's edge. High-quality 3D render style, colorful and engaging, mobile game icon style.",
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: "512px"
        }
      },
    });
    
    const candidate = response.candidates?.[0];
    if (candidate?.content?.parts) {
      for (const part of candidate.content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    return null;
  } catch (error) {
    console.error('Error generating icon:', error);
    return null;
  }
}
