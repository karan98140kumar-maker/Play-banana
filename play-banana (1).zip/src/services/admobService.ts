import { AdMob, AdOptions, RewardAdOptions, BannerAdOptions, BannerAdPosition, BannerAdSize } from '@capacitor-community/admob';

export const initializeAdMob = async () => {
  await AdMob.initialize({
    testingDevices: [],
    initializeForTesting: true,
  });
};

export const showBannerAd = async () => {
  const options: BannerAdOptions = {
    adId: 'ca-app-pub-3940256099942544/6300978111', // Test Banner Ad ID
    adSize: BannerAdSize.BANNER,
    position: BannerAdPosition.BOTTOM_CENTER,
    margin: 60, // Margin to avoid overlapping bottom nav
    isTesting: true
  };

  try {
    await AdMob.showBanner(options);
  } catch (error) {
    console.error('AdMob Banner Error:', error);
  }
};

export const hideBannerAd = async () => {
  try {
    await AdMob.hideBanner();
  } catch (error) {
    console.error('AdMob Hide Banner Error:', error);
  }
};

export const showRewardAd = async (onReward: (reward: any) => void, onDismiss: () => void) => {
  const options: RewardAdOptions = {
    adId: 'ca-app-pub-3940256099942544/5224354917', // Test Reward Ad ID
  };

  try {
    await AdMob.prepareRewardVideoAd(options);
    const reward = await AdMob.showRewardVideoAd();
    if (reward) {
      onReward(reward);
    }
  } catch (error) {
    console.error('AdMob Reward Error:', error);
    // If ad fails, we might want to still reward for testing or show error
    onDismiss();
  }
};

export const showInterstitialAd = async () => {
  const options: AdOptions = {
    adId: 'ca-app-pub-3940256099942544/1033173712', // Test Interstitial Ad ID
    // isTesting: true,
  };

  try {
    await AdMob.prepareInterstitial(options);
    await AdMob.showInterstitial();
  } catch (error) {
    console.error('AdMob Interstitial Error:', error);
  }
};
