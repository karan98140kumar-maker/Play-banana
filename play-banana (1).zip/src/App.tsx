import { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import { useApp } from './context/AppContext';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import NotificationScheduler from './components/NotificationScheduler';
import SplashScreen from './components/SplashScreen';
import ErrorBoundary from './components/ErrorBoundary';
import { initializeAdMob } from './services/admobService';

export default function App() {
  const { user, loading: authLoading } = useAuth();
  const { loading: appLoading } = useApp();
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    initializeAdMob()
      .then(() => console.log('AdMob Initialized Successfully'))
      .catch(err => console.error('AdMob Init Error:', err));
  }, []);

  if (showSplash) {
    return <SplashScreen onFinish={() => {
      setShowSplash(false);
    }} />;
  }

  if (authLoading || appLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="antialiased text-slate-900">
        <NotificationScheduler />
        {!user ? <Auth /> : <Dashboard />}
      </div>
    </ErrorBoundary>
  );
}
